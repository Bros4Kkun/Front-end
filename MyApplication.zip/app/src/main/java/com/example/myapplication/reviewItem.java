package com.example.myapplication;

public class reviewItem {

    private int ci_profile;
    private String tvId, tvReCa, tvPoint, tvStory;

    public int getCi_profile() {
        return ci_profile;
    }

    public void setCi_profile(int ci_profile) {
        this.ci_profile = ci_profile;
    }

    public String getTvId() {
        return tvId;
    }

    public void setTvId(String tvId) {
        this.tvId = tvId;
    }

    public String getTvReCa() {
        return tvReCa;
    }

    public void setTvReCa(String tvReCa) {
        this.tvReCa = tvReCa;
    }

    public String getTvPoint() {
        return tvPoint;
    }

    public void setTvPoint(String tvPoint) {
        this.tvPoint = tvPoint;
    }

    public String getTvStory() {
        return tvStory;
    }

    public void setTvStory(String tvStory) {
        this.tvStory = tvStory;
    }
}
